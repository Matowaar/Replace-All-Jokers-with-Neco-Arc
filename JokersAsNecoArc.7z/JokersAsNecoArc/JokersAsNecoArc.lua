--- STEAMODDED HEADER
--- MOD_NAME: Jokers As Neco-Arc
--- MOD_ID: JokersAsNecoArc
--- MOD_AUTHOR: [Matowaar]
--- MOD_DESCRIPTION: Replaces all jokers for Neco-Arc from the visual novel Tsukihime, good for streaming.‎ ‎ ‎Photograph joker artwork by Raddishe.

----------------------------------------------
------------MOD CODE -------------------------

function SMODS.INIT.JokersAsNecoArc()

    local tpt_mod = SMODS.findModByID("JokersAsNecoArc")

    local sprite_jkr = SMODS.Sprite:new("Joker", tpt_mod.path, "Jokers.png", 71, 95, "asset_atli")

    sprite_jkr:register()
end

----------------------------------------------
------------MOD CODE END----------------------
